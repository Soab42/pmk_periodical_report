# pmk_periodical_report

1. Download node js and install

```
https://nodejs.org/en/download/current
```

2. Copy and run this command on windows shell or download zip file

```
git clone https://github.com/Soab42/pmk_periodical_report

```

3. double click on install.bat file to install.

4. change you credentials

5. double click on run.bat file to run server

6. now got to this url

   https://periodical-report.vercel.app/
